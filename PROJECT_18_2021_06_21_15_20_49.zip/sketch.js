var monkey, monkey_running, monkey_jumping
var banana
var obstacleImage, obstacleGroup
var background

var score

function preload(){
  
  background=loadImage("jungle.png");
  monkey_running=loadAnimation("monkey_01","monkey_02","monkey_03","monkey_04","monkey_05","monkey_06","monkey_07","monkey_08","monkey_09","monkey_10");
               
  
}



function setup() {
  createCanvas(400, 400);\
  
  background=createSprite
}

function draw() {
  background(220);
}